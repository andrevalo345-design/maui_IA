# Manual de usuario — AsistenteIA

**Asistente académico móvil con inteligencia artificial**
Proyecto final — Diseño de Software para Equipos Móviles (VIII semestre)

---

## 1. ¿Qué es AsistenteIA?

AsistenteIA es una aplicación móvil que permite escribir preguntas o
instrucciones académicas, enviarlas a un modelo de inteligencia artificial
a través de una API pública, y consultar las respuestas más tarde desde un
historial guardado en el propio dispositivo.

La aplicación **no reemplaza** el criterio del estudiante: toda respuesta
generada por la IA debe verificarse antes de usarse en un trabajo académico.

## 2. Requisitos antes de usarla

- Un dispositivo o emulador con Windows o Android.
- Conexión a internet.
- Una clave de API (publicable) del proveedor de IA utilizado (Pollinations).
  Esta clave se ingresa una sola vez desde la app; consulta a tu equipo o
  docente cómo obtenerla si no la tienes.

## 3. Pantallas de la aplicación

### 3.1 Inicio
Es la primera pantalla que se ve al abrir la app. Muestra:
- El propósito de AsistenteIA.
- Recomendaciones de uso (no ingresar datos personales, verificar respuestas, etc.).
- Tres accesos directos: **Consultar IA**, **Ver historial** y **Configuración**.

### 3.2 Consultar IA
Aquí se hace una consulta a la inteligencia artificial:

1. (Opcional) Elige una **plantilla de prompt** en el selector superior
   (por ejemplo "Explica el concepto de:"). El texto aparecerá en el cuadro
   de escritura y puedes completarlo o modificarlo.
2. Escribe tu pregunta en el cuadro de texto (mínimo 5 caracteres, máximo 2000).
3. Elige el **modelo** de IA a usar y, si quieres, escribe una **categoría**
   (por ejemplo "Bases de datos", "Matemáticas") para organizar el historial.
4. Pulsa **Consultar**. Mientras se procesa verás un indicador de carga y el
   mensaje "Consultando el servicio...". Puedes pulsar **Cancelar** en
   cualquier momento para detener la solicitud.
5. Cuando llega la respuesta, aparece en el recuadro inferior junto con el
   aviso "Respuesta recibida. Verifique la información antes de usarla."
6. Si quieres conservarla, pulsa **Guardar en historial**.

**Mensajes que puedes ver:**
| Mensaje | Significado |
|---|---|
| "La consulta es demasiado corta." | Escribe al menos 5 caracteres. |
| "La consulta supera 2000 caracteres." | Acorta tu pregunta. |
| "Configure la clave de la API." | Ve a Configuración e ingresa tu clave. |
| "Error del servicio: ..." | El proveedor devolvió un error (revisa tu clave o intenta más tarde). |
| "Consulta cancelada o tiempo agotado." | Pulsaste Cancelar o la respuesta tardó demasiado. |

### 3.3 Historial
Lista todas las consultas guardadas, de la más reciente a la más antigua.

- Usa la **barra de búsqueda** para filtrar por texto de la pregunta o por categoría.
- Pulsa **Abrir** en cualquier fila para ver el detalle completo.
- Pulsa **Eliminar** para borrar una consulta; la app pedirá confirmación
  antes de hacerlo.
- Las consultas marcadas como verificadas muestran un ✔ junto a la fecha.

### 3.4 Detalle
Muestra la pregunta completa, la respuesta completa, la fecha, la categoría
y un interruptor **"Marcar como verificada"**. Actívalo únicamente después
de haber contrastado la respuesta con una fuente confiable (libro,
documentación oficial, tu docente, etc.).

### 3.5 Configuración y acerca de
- **Clave de API**: campo oculto (tipo contraseña) donde ingresas tu clave.
  Pulsa **Guardar** para almacenarla de forma segura en el dispositivo, o
  **Eliminar clave** para borrarla. La clave nunca se muestra en pantalla
  una vez guardada.
- **Modelo** y **Probar conexión**: permite elegir el modelo de IA y
  verificar que la clave funciona antes de usar la app.
- **Acerca de**: explica el propósito académico del proyecto, el proveedor
  de IA utilizado, y las siguientes advertencias importantes:
  - No ingreses datos personales, contraseñas ni información confidencial
    en tus consultas.
  - Las respuestas de la IA pueden contener errores o información
    inventada ("alucinaciones"); siempre deben verificarse.

## 4. Buenas prácticas de uso

- Formula preguntas claras y específicas para obtener mejores respuestas.
- Usa las categorías del historial para organizar tus consultas por materia.
- Verifica cualquier dato, cifra o cita que la IA te entregue antes de
  usarlo en un trabajo o examen.
- No compartas tu clave de API con terceros ni la incluyas en capturas de
  pantalla que vayas a publicar.

## 5. Solución de problemas frecuentes

| Problema | Qué hacer |
|---|---|
| La app dice que no hay conexión | Verifica tu wifi o datos móviles y vuelve a intentar. |
| No aparece ninguna respuesta | Revisa que tu clave esté configurada y sea válida (botón "Probar conexión"). |
| El historial aparece vacío | Asegúrate de haber pulsado "Guardar en historial" después de recibir una respuesta. |
| Eliminé una consulta por error | La eliminación es permanente; deberás repetir la consulta si necesitas la respuesta de nuevo. |
