using SQLite;
using AsistenteIA.Models;

namespace AsistenteIA.Services;

// RF05, RF06: guarda, consulta, filtra y elimina el historial de conversaciones.
public class DatabaseService
{
    private SQLiteAsyncConnection? _db;

    private async Task InitAsync()
    {
        if (_db is not null) return;

        string dbPath = Path.Combine(FileSystem.AppDataDirectory, "asistenteia.db3");
        _db = new SQLiteAsyncConnection(dbPath);
        await _db.CreateTableAsync<ConversationRecord>();
    }

    public async Task<int> SaveAsync(ConversationRecord record)
    {
        await InitAsync();
        return await _db!.InsertAsync(record);
    }

    public async Task<List<ConversationRecord>> GetAllAsync()
    {
        await InitAsync();
        return await _db!.Table<ConversationRecord>()
            .OrderByDescending(r => r.CreatedAt)
            .ToListAsync();
    }

    public async Task<ConversationRecord?> GetByIdAsync(int id)
    {
        await InitAsync();
        return await _db!.Table<ConversationRecord>()
            .FirstOrDefaultAsync(r => r.Id == id);
    }

    public async Task<int> UpdateAsync(ConversationRecord record)
    {
        await InitAsync();
        return await _db!.UpdateAsync(record);
    }

    public async Task<int> DeleteAsync(ConversationRecord record)
    {
        await InitAsync();
        return await _db!.DeleteAsync(record);
    }
}
