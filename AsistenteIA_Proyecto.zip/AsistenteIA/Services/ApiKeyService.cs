namespace AsistenteIA.Services;

// RF08: registra/actualiza la clave sin mostrarla en pantalla.
// La clave NUNCA se escribe en código, archivos de configuración ni logs.
public class ApiKeyService
{
    private const string KeyName = "pollinations_api_key";

    public Task SaveAsync(string key) =>
        SecureStorage.Default.SetAsync(KeyName, key.Trim());

    public Task<string?> GetAsync() =>
        SecureStorage.Default.GetAsync(KeyName);

    public bool Remove() => SecureStorage.Default.Remove(KeyName);

    public async Task<bool> HasKeyAsync()
    {
        string? key = await GetAsync();
        return !string.IsNullOrWhiteSpace(key);
    }

    // Modelos autorizados por el proveedor. En un caso real se podrían
    // consultar dinámicamente en la documentación de Pollinations.
    public static readonly List<string> AvailableModels =
    [
        "openai/gpt-5.4-nano",
        "openai/gpt-5.4-mini",
        "mistral/mistral-small"
    ];
}
