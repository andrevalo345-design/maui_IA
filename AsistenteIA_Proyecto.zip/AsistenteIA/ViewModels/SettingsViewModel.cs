using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using AsistenteIA.Services;

namespace AsistenteIA.ViewModels;

public partial class SettingsViewModel : ObservableObject
{
    private readonly ApiKeyService _keyService;
    private readonly AiService _aiService;

    [ObservableProperty] private string apiKeyInput = string.Empty;
    [ObservableProperty] private string selectedModel = ApiKeyService.AvailableModels[0];
    [ObservableProperty] private string statusMessage = string.Empty;
    [ObservableProperty] private bool hasKey;
    [ObservableProperty] private bool isBusy;

    public List<string> AvailableModels => ApiKeyService.AvailableModels;

    public SettingsViewModel(ApiKeyService keyService, AiService aiService)
    {
        _keyService = keyService;
        _aiService = aiService;
        _ = RefreshHasKeyAsync();
    }

    private async Task RefreshHasKeyAsync() => HasKey = await _keyService.HasKeyAsync();

    // RF08: guarda/actualiza la clave sin mostrarla en pantalla.
    [RelayCommand]
    private async Task SaveKeyAsync()
    {
        if (string.IsNullOrWhiteSpace(ApiKeyInput))
        {
            StatusMessage = "Ingrese una clave válida.";
            return;
        }

        await _keyService.SaveAsync(ApiKeyInput);
        ApiKeyInput = string.Empty; // nunca se conserva en pantalla ni en memoria visible
        await RefreshHasKeyAsync();
        StatusMessage = "Clave guardada de forma segura.";
    }

    [RelayCommand]
    private async Task RemoveKeyAsync()
    {
        bool confirm = await Shell.Current.DisplayAlert(
            "Eliminar clave", "¿Desea eliminar la clave guardada?", "Eliminar", "Cancelar");
        if (!confirm) return;

        _keyService.Remove();
        await RefreshHasKeyAsync();
        StatusMessage = "Clave eliminada.";
    }

    [RelayCommand]
    private async Task TestConnectionAsync()
    {
        IsBusy = true;
        StatusMessage = "Probando conexión...";
        try
        {
            bool ok = await _aiService.TestConnectionAsync(SelectedModel);
            StatusMessage = ok ? "Conexión exitosa." : "No fue posible conectar con el servicio.";
        }
        catch (Exception ex)
        {
            StatusMessage = $"Error: {ex.Message}";
        }
        finally
        {
            IsBusy = false;
        }
    }
}
