using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using AsistenteIA.Models;
using AsistenteIA.Services;

namespace AsistenteIA.ViewModels;

[QueryProperty(nameof(Id), "Id")]
public partial class DetailViewModel : ObservableObject
{
    private readonly DatabaseService _databaseService;

    [ObservableProperty] private int id;
    [ObservableProperty] private ConversationRecord? record;
    [ObservableProperty] private string statusMessage = string.Empty;

    public DetailViewModel(DatabaseService databaseService)
    {
        _databaseService = databaseService;
    }

    partial void OnIdChanged(int value)
    {
        _ = LoadAsync(value);
    }

    private async Task LoadAsync(int id)
    {
        Record = await _databaseService.GetByIdAsync(id);
    }

    // Permite marcar la respuesta como verificada tras contrastarla con fuentes confiables.
    [RelayCommand]
    private async Task ToggleVerifiedAsync()
    {
        if (Record is null) return;

        Record.IsVerified = !Record.IsVerified;
        await _databaseService.UpdateAsync(Record);
        StatusMessage = Record.IsVerified
            ? "Marcada como verificada."
            : "Marca de verificación retirada.";

        // Forzar refresco de la propiedad para la UI.
        var updated = Record;
        Record = null;
        Record = updated;
    }
}
