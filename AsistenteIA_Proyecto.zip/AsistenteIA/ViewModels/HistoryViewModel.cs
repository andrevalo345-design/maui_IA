using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using AsistenteIA.Models;
using AsistenteIA.Services;
using AsistenteIA.Views;
using System.Collections.ObjectModel;

namespace AsistenteIA.ViewModels;

public partial class HistoryViewModel : ObservableObject
{
    private readonly DatabaseService _databaseService;
    private List<ConversationRecord> _allRecords = [];

    [ObservableProperty] private bool isBusy;
    [ObservableProperty] private string searchText = string.Empty;
    [ObservableProperty] private string statusMessage = string.Empty;

    public ObservableCollection<ConversationRecord> Records { get; } = [];

    public HistoryViewModel(DatabaseService databaseService)
    {
        _databaseService = databaseService;
    }

    // RF06: consultar y filtrar el historial.
    [RelayCommand]
    private async Task LoadAsync()
    {
        IsBusy = true;
        try
        {
            _allRecords = await _databaseService.GetAllAsync();
            ApplyFilter();
        }
        finally
        {
            IsBusy = false;
        }
    }

    partial void OnSearchTextChanged(string value) => ApplyFilter();

    private void ApplyFilter()
    {
        Records.Clear();
        IEnumerable<ConversationRecord> filtered = _allRecords;

        if (!string.IsNullOrWhiteSpace(SearchText))
        {
            filtered = filtered.Where(r =>
                r.Prompt.Contains(SearchText, StringComparison.OrdinalIgnoreCase) ||
                r.Category.Contains(SearchText, StringComparison.OrdinalIgnoreCase));
        }

        foreach (var record in filtered)
            Records.Add(record);
    }

    [RelayCommand]
    private async Task OpenDetailAsync(ConversationRecord record)
    {
        if (record is null) return;
        await Shell.Current.GoToAsync(nameof(DetailPage), new Dictionary<string, object>
        {
            { "Id", record.Id }
        });
    }

    // RF06: eliminar con confirmación.
    [RelayCommand]
    private async Task DeleteAsync(ConversationRecord record)
    {
        if (record is null) return;

        bool confirm = await Shell.Current.DisplayAlert(
            "Eliminar",
            "¿Desea eliminar esta consulta del historial?",
            "Eliminar",
            "Cancelar");

        if (!confirm) return;

        await _databaseService.DeleteAsync(record);
        _allRecords.Remove(record);
        ApplyFilter();
        StatusMessage = "Consulta eliminada.";
    }
}
