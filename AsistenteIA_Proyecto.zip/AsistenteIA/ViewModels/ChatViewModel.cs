using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using AsistenteIA.Models;
using AsistenteIA.Services;
using System.Collections.ObjectModel;

namespace AsistenteIA.ViewModels;

public partial class ChatViewModel : ObservableObject
{
    private readonly AiService _aiService;
    private readonly DatabaseService _databaseService;
    private CancellationTokenSource? _cts;

    [ObservableProperty] private string prompt = string.Empty;
    [ObservableProperty] private string answer = string.Empty;
    [ObservableProperty] private string statusMessage = string.Empty;
    [ObservableProperty] private bool isBusy;
    [ObservableProperty] private bool hasAnswer;
    [ObservableProperty] private string selectedModel = ApiKeyService.AvailableModels[0];
    [ObservableProperty] private string category = "General";
    [ObservableProperty] private string? selectedTemplate;

    // RF07: plantillas de prompts académicos editables. El usuario elige una
    // y puede modificarla libremente en el Editor antes de enviarla.
    public ObservableCollection<string> PromptTemplates { get; } =
    [
        "Explica el concepto de: ",
        "Resume en 5 puntos clave el tema: ",
        "Dame un ejemplo práctico sobre: ",
        "Compara y contrasta: ",
        "Genera 3 preguntas de repaso sobre: "
    ];

    public List<string> AvailableModels => ApiKeyService.AvailableModels;

    public ChatViewModel(AiService aiService, DatabaseService databaseService)
    {
        _aiService = aiService;
        _databaseService = databaseService;
    }

    partial void OnSelectedTemplateChanged(string? value)
    {
        if (!string.IsNullOrEmpty(value))
            Prompt = value;
    }

    [RelayCommand]
    private async Task AskAsync()
    {
        if (IsBusy) return;
        _cts = new CancellationTokenSource();
        IsBusy = true;
        HasAnswer = false;
        StatusMessage = "Consultando el servicio...";

        try
        {
            Answer = await _aiService.AskAsync(Prompt, SelectedModel, _cts.Token);
            HasAnswer = true;
            StatusMessage = "Respuesta recibida. Verifique la información antes de usarla.";
        }
        catch (OperationCanceledException)
        {
            StatusMessage = "Consulta cancelada o tiempo agotado.";
        }
        catch (HttpRequestException ex)
        {
            StatusMessage = $"Error del servicio: {ex.StatusCode}";
        }
        catch (Exception ex)
        {
            // Cubre ArgumentException (RF02) e InvalidOperationException (clave faltante)
            StatusMessage = ex.Message;
        }
        finally
        {
            IsBusy = false;
        }
    }

    [RelayCommand]
    private void Cancel() => _cts?.Cancel();

    // RF05: guarda la consulta y la respuesta en SQLite.
    [RelayCommand]
    private async Task SaveAsync()
    {
        if (!HasAnswer || string.IsNullOrWhiteSpace(Answer))
        {
            StatusMessage = "No hay una respuesta para guardar.";
            return;
        }

        var record = new ConversationRecord
        {
            Prompt = Prompt,
            Answer = Answer,
            Category = string.IsNullOrWhiteSpace(Category) ? "General" : Category,
            CreatedAt = DateTime.UtcNow,
            IsVerified = false
        };

        await _databaseService.SaveAsync(record);
        StatusMessage = "Guardado en el historial.";
    }
}
