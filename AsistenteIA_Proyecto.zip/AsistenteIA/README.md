# AsistenteIA — código base del proyecto final

Este paquete contiene el **código fuente completo** de la app AsistenteIA
descrita en la guía (RF01–RF10, 5 pantallas, MVVM, SQLite, consumo de la
API REST de IA). Está pensado para copiarse dentro del proyecto que crees
en Visual Studio siguiendo la **Fase 1** de la guía.

## 1. Crear el proyecto (Fase 1)

1. Visual Studio Community → nuevo proyecto → **.NET MAUI App** → nombre `AsistenteIA`.
2. Ejecuta la plantilla por defecto una vez (Windows Machine o emulador Android) antes de tocar nada.
3. Instala desde NuGet:
   - `CommunityToolkit.Mvvm`
   - `sqlite-net-pcl`
4. Borra `MainPage.xaml` / `MainPage.xaml.cs` del template (no se usan; Shell los reemplaza).

## 2. Copiar los archivos

Copia las carpetas tal cual dentro de la raíz del proyecto (mismos nombres de carpeta):

```
Models/ChatModels.cs
Models/ConversationRecord.cs
Services/ApiKeyService.cs
Services/AiService.cs
Services/DatabaseService.cs
ViewModels/ChatViewModel.cs
ViewModels/HistoryViewModel.cs
ViewModels/DetailViewModel.cs
ViewModels/SettingsViewModel.cs
Views/HomePage.xaml (+ .xaml.cs)
Views/ChatPage.xaml (+ .xaml.cs)
Views/HistoryPage.xaml (+ .xaml.cs)
Views/DetailPage.xaml (+ .xaml.cs)
Views/SettingsPage.xaml (+ .xaml.cs)
```

Reemplaza también:
```
AppShell.xaml (+ .xaml.cs)
MauiProgram.cs
```

> En Visual Studio, para cada `.xaml` usa "Agregar → Nuevo elemento → .NET MAUI ContentPage (XAML)"
> con el nombre correspondiente y luego pega el contenido, para que el `.g.cs` y el `x:Class` se generen bien.
> Asegúrate de que el `x:Class` de cada XAML coincida con `AsistenteIA.Views.<Nombre>`.

## 3. Verificar el namespace del proyecto

Todo el código usa el namespace raíz `AsistenteIA`. Si tu proyecto se creó con otro
nombre, ajusta los `namespace` y los `using` en cada archivo (Buscar y reemplazar).

## 4. Configurar la clave de API (Fase 2 y 4)

- La app **no trae ninguna clave escrita**. Debes obtener una clave publicable
  de Pollinations (ver `https://gen.pollinations.ai/docs`) e ingresarla desde
  la pantalla **Configuración** la primera vez que ejecutes la app.
- La clave se guarda con `SecureStorage`, nunca en el código ni en Git.

## 5. Qué cubre cada archivo (mapeo con la guía)

| Archivo | Fase / RF que resuelve |
|---|---|
| `Models/ChatModels.cs` | Fase 3 |
| `Services/ApiKeyService.cs` | Fase 4, RF08 |
| `Services/AiService.cs` | Fase 5, RF01–RF04 |
| `MauiProgram.cs` | Fase 6 |
| `ViewModels/ChatViewModel.cs`, `Views/ChatPage.xaml` | Fase 7–8, RF01–RF04, RF07 |
| `AppShell.xaml` | Fase 9 |
| `Models/ConversationRecord.cs`, `Services/DatabaseService.cs` | Fase 10, RF05–RF06 |
| `ViewModels/HistoryViewModel.cs`, `Views/HistoryPage.xaml` | RF06 |
| `ViewModels/DetailViewModel.cs`, `Views/DetailPage.xaml` | RF06, Fase 12 (verificación) |
| `ViewModels/SettingsViewModel.cs`, `Views/SettingsPage.xaml` | Fase 11, RF08–RF09 |

## 6. Pendiente por hacer tú (no se puede generar automáticamente)

- **Fase 13 — Plan de pruebas**: ejecutar los 10 casos (P01–P10) en tu máquina/emulador
  y documentar evidencia (capturas/video). El código soporta todos los casos
  (validación de prompt, manejo de errores HTTP, cancelación, CRUD, etc.), pero
  las evidencias las generas tú al correr la app.
- **Fase 14**: repartir roles en el equipo y hacer commits de cada integrante.
- **Manual de usuario, matriz de riesgos y sustentación**: documentos que debes
  redactar con tu equipo (puedo ayudarte a redactarlos si me lo pides).
- Revisa que el `AndroidManifest.xml` / permisos de Internet estén habilitados
  si pruebas en Android (por defecto el template ya incluye el permiso `INTERNET`).

## 7. Notas de diseño

- `SelectedTemplate` en `ChatViewModel` rellena el `Editor` al elegir una
  plantilla (RF07); el usuario puede seguir editando el texto libremente.
- `DetailPage` usa un `Switch` para alternar `IsVerified` y actualizarlo en SQLite.
- El manejo de errores en `AskAsync`/`AskCommand` cubre: prompt inválido
  (`ArgumentException`), clave faltante (`InvalidOperationException`),
  error HTTP (`HttpRequestException`) y cancelación/timeout (`OperationCanceledException`),
  tal como pide RF04 y el plan de pruebas.
