using AsistenteIA.ViewModels;

namespace AsistenteIA.Views;

public partial class DetailPage : ContentPage
{
    private readonly DetailViewModel _viewModel;

    public DetailPage(DetailViewModel viewModel)
    {
        InitializeComponent();
        BindingContext = _viewModel = viewModel;
    }

    private async void OnVerifiedToggled(object sender, ToggledEventArgs e)
    {
        await _viewModel.ToggleVerifiedCommand.ExecuteAsync(null);
    }
}
