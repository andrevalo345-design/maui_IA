using AsistenteIA.Models;
using AsistenteIA.ViewModels;

namespace AsistenteIA.Views;

public partial class HistoryPage : ContentPage
{
    private readonly HistoryViewModel _viewModel;

    public HistoryPage(HistoryViewModel viewModel)
    {
        InitializeComponent();
        BindingContext = _viewModel = viewModel;
    }

    protected override async void OnAppearing()
    {
        base.OnAppearing();
        await _viewModel.LoadCommand.ExecuteAsync(null);
    }

    private async void OnOpenClicked(object sender, EventArgs e)
    {
        if (sender is Button { BindingContext: ConversationRecord record })
            await _viewModel.OpenDetailCommand.ExecuteAsync(record);
    }

    private async void OnDeleteClicked(object sender, EventArgs e)
    {
        if (sender is Button { BindingContext: ConversationRecord record })
            await _viewModel.DeleteCommand.ExecuteAsync(record);
    }
}
