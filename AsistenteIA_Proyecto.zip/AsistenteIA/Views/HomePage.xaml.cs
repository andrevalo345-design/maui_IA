namespace AsistenteIA.Views;

public partial class HomePage : ContentPage
{
    public HomePage()
    {
        InitializeComponent();
    }

    private async void OnConsultarClicked(object sender, EventArgs e) =>
        await Shell.Current.GoToAsync("//ChatPage");

    private async void OnHistorialClicked(object sender, EventArgs e) =>
        await Shell.Current.GoToAsync("//HistoryPage");

    private async void OnConfiguracionClicked(object sender, EventArgs e) =>
        await Shell.Current.GoToAsync("//SettingsPage");
}
